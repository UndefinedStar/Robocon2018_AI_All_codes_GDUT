camshift+霍夫只能识别圆面，不能识别圆环
